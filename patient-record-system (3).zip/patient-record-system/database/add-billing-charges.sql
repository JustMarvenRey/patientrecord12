-- ============================================================
-- BILLING = professional fees + laboratory charges
--
-- api/auto-migrate.php applies this automatically the first time the app connects, so running
-- it by hand is optional. Run it ONCE (not repeat-safe).
-- ============================================================

-- Price list: what each laboratory test costs
ALTER TABLE LABORATORY_TEST ADD COLUMN Price DECIMAL(10,2) NOT NULL DEFAULT 0.00;

-- Price copied onto each lab record when it is ordered (so later price changes don't alter old bills)
ALTER TABLE LABORATORY ADD COLUMN Price DECIMAL(10,2) NULL DEFAULT NULL;
UPDATE LABORATORY l JOIN LABORATORY_TEST t ON t.TestID = l.TestID SET l.Price = t.Price;

-- Set your real prices, e.g.:
-- UPDATE LABORATORY_TEST SET Price = 250.00 WHERE TestName = 'Complete Blood Count (CBC)';
-- (or edit them on the Laboratory Tests page)

-- ============================================================
-- ADMIN-MANAGED LAB FEES: lab fees an Admin adds straight onto a bill
-- (api/auto-migrate.php also creates this table automatically)
-- ============================================================
CREATE TABLE IF NOT EXISTS BILL_LAB_CHARGE (
    LabChargeID INT AUTO_INCREMENT PRIMARY KEY,
    BillID      INT NOT NULL,
    TestID      INT NULL,                  -- the price-list test it was picked from, if any
    Description VARCHAR(150) NOT NULL,
    Amount      DECIMAL(10,2) NOT NULL,
    Status      VARCHAR(10) NOT NULL DEFAULT 'Active',
    KEY idx_blc_bill (BillID),
    CONSTRAINT fk_blc_bill FOREIGN KEY (BillID) REFERENCES BILLING(BillID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
