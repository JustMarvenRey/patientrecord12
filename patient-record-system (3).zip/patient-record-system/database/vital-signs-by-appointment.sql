-- ============================================================
-- Vital signs are now recorded by STAFF when an appointment is
-- booked (before any consultation exists), so VITAL_SIGN is keyed
-- by AppointmentID. ConsultationID stays (nullable) for old rows.
-- Run once, after add-vital-signs.sql.
-- ============================================================
USE patient_record_system;

ALTER TABLE VITAL_SIGN ADD COLUMN AppointmentID INT NULL AFTER VitalSignID;

-- Back-fill existing vital signs from their consultation's appointment
UPDATE VITAL_SIGN v
JOIN CONSULTATION c ON c.ConsultationID = v.ConsultationID
SET v.AppointmentID = c.AppointmentID;

-- A vital sign can now exist before its consultation does
ALTER TABLE VITAL_SIGN MODIFY ConsultationID INT NULL;

-- One vital-sign record per appointment
ALTER TABLE VITAL_SIGN ADD CONSTRAINT uq_vital_appointment UNIQUE (AppointmentID);
ALTER TABLE VITAL_SIGN ADD CONSTRAINT fk_vital_appointment
    FOREIGN KEY (AppointmentID) REFERENCES APPOINTMENT(AppointmentID);
