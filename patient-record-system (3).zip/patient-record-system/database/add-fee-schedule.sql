-- ============================================================
-- FEE SCHEDULE: the Admin sets each doctor's professional fee
--
-- api/auto-migrate.php adds this automatically the first time the app connects, so running it by
-- hand is optional. Run it ONCE (not repeat-safe).
-- ============================================================
ALTER TABLE USERS ADD COLUMN ProfessionalFee DECIMAL(10,2) NOT NULL DEFAULT 0.00;

-- Set the fees on the Fee Schedule page (Admin), or by hand, e.g.:
-- UPDATE USERS SET ProfessionalFee = 500.00 WHERE Username = 'jramirez';
-- Laboratory test prices already live in LABORATORY_TEST.Price (see add-billing-charges.sql).
