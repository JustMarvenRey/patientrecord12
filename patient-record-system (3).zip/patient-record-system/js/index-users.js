import { cmpText, cmpNum, sortBySelect } from "./sort-utils.js?v=20261107";
import { viewModal } from "./modules-users/view.js?v=20261107";
import { updateModal } from "./modules-users/update.js?v=20261107";
import { deleteModal } from "./modules-users/delete.js?v=20261107";
import { actingUserId, checkResult, esc, getAssignableRoles, getLinkablePatients, isValidPhone, patientOptionLabel } from "./modules-users/common.js?v=20261107";

const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const SORTS = {
  "last-asc":     (a, b) => cmpText(a.LastName, b.LastName) || cmpText(a.FirstName, b.FirstName),
  "last-desc":    (a, b) => cmpText(b.LastName, a.LastName) || cmpText(b.FirstName, a.FirstName),
  "first-asc":    (a, b) => cmpText(a.FirstName, b.FirstName) || cmpText(a.LastName, b.LastName),
  "username-asc": (a, b) => cmpText(a.Username, b.Username),
  "role-asc":     (a, b) => cmpText(a.RoleName, b.RoleName) || cmpText(a.LastName, b.LastName),
  "status-asc":   (a, b) => cmpText(a.Status, b.Status) || cmpText(a.LastName, b.LastName),
};

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("sort-by").addEventListener("change", () => displayUsers());
  loadRoles();
  loadSpecializations();
  displayUsers();

  document.getElementById("role").addEventListener("change", () => {
    toggleDoctorFields();
    togglePatientFields();
  });
  document.getElementById("patient-link").addEventListener("change", fillFromPatient);
  document.getElementById("btn-submit").addEventListener("click", insertUser);
  document.getElementById("show-inactive").addEventListener("change", displayUsers);
});

const loadRoles = async () => {
  const roles = await getAssignableRoles();
  const select = document.getElementById("role");
  roles.forEach((r) => {
    const option = document.createElement("option");
    option.value = r.RoleID;
    option.textContent = r.RoleName;
    select.appendChild(option);
  });
};

// Specializations only apply to doctors, so that field only shows up when the
// selected role is "Doctor".
const isDoctorRoleSelected = () => {
  const select = document.getElementById("role");
  return select.selectedOptions[0]?.textContent === "Doctor";
};

const toggleDoctorFields = () => {
  document.getElementById("doctor-fields").style.display = isDoctorRoleSelected() ? "flex" : "none";
};

// A Patient login is tied to one patient record, so that picker only shows for the "Patient" role.
const isPatientRoleSelected = () => {
  const select = document.getElementById("role");
  return select.selectedOptions[0]?.textContent === "Patient";
};

let linkablePatients = [];

// Name and phone come from the patient record, so they are filled in and locked while a patient is chosen.
const fillFromPatient = () => {
  const p = linkablePatients.find((x) => String(x.PatientID) === document.getElementById("patient-link").value);
  const lock = isPatientRoleSelected() && !!p;
  const first = document.getElementById("first-name");
  const last = document.getElementById("last-name");
  const phone = document.getElementById("phone");
  [first, last, phone].forEach((el) => (el.readOnly = lock));
  if (lock) {
    first.value = p.FirstName;
    last.value = p.LastName;
    phone.value = p.Phone ?? "";
  }
  const box = document.getElementById("patient-details");
  box.style.display = lock ? "block" : "none";
  document.getElementById("patient-details-body").innerHTML = lock
    ? `<div><strong>${esc(p.LastName)}, ${esc(p.FirstName)}</strong></div>
       <div>Born ${esc(p.DateOfBirth)}</div>
       <div>Phone: ${esc(p.Phone || "—")}</div>
       <div>Address: ${esc(p.Address || "—")}</div>`
    : "";
};

const togglePatientFields = async () => {
  const show = isPatientRoleSelected();
  document.getElementById("patient-fields").style.display = show ? "flex" : "none";
  if (!show) {
    // leaving the Patient role: unlock the name/phone boxes again
    ["first-name", "last-name", "phone"].forEach((id) => (document.getElementById(id).readOnly = false));
    document.getElementById("patient-details").style.display = "none";
    return;
  }
  const select = document.getElementById("patient-link");
  const keep = select.value;
  linkablePatients = await getLinkablePatients();
  select.innerHTML = `<option value="">-- Select patient --</option>` +
    linkablePatients.map((p) => `<option value="${p.PatientID}">${esc(patientOptionLabel(p))}</option>`).join("");
  select.value = keep;
  fillFromPatient();
};

// Renders the specializations lookup as a list of checkboxes.
const loadSpecializations = async () => {
  const container = document.getElementById("specializations");
  try {
    const response = await axios.get(`${baseApiUrl}/specializations.php`, {
      params: { operation: "getSpecializations" },
    });
    container.innerHTML = "";
    response.data.filter((spec) => spec.Status !== "Inactive").forEach((spec) => {
      const wrapper = document.createElement("div");
      wrapper.classList.add("form-check");

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.classList.add("form-check-input");
      checkbox.value = spec.SpecializationID;
      checkbox.id = `spec-${spec.SpecializationID}`;

      const label = document.createElement("label");
      label.classList.add("form-check-label");
      label.htmlFor = checkbox.id;
      label.textContent = spec.SpecializationName;

      wrapper.appendChild(checkbox);
      wrapper.appendChild(label);
      container.appendChild(wrapper);
    });
  } catch (err) {
    container.innerHTML = `<span class="text-danger small">Could not load specializations.</span>`;
  }
};

const getSelectedSpecializationIds = () =>
  [...document.querySelectorAll("#specializations input[type='checkbox']:checked")].map((c) => c.value);

const displayUsers = async () => {
  const response = await axios.get(`${baseApiUrl}/users.php`, {
    params: {
      operation: "getAllUsers",
      json: JSON.stringify({ actingUserId: actingUserId() }),
    },
  });
  if (response.status == 200 && Array.isArray(response.data)) {
    displayUsersTable(response.data);
  } else {
    alert("Error loading accounts. Only administrators can view this page.");
  }
};

const displayUsersTable = (users) => {
  const showInactive = document.getElementById("show-inactive").checked;
  const tableDiv = document.getElementById("table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `
    <thead>
      <tr><th>NAME</th><th>USERNAME</th><th>PHONE</th><th>ROLE</th><th>SPECIALIZATIONS</th><th>STATUS</th><th>ACTION</th></tr>
    </thead>
  `;

  const tbody = document.createElement("tbody");
  const me = Number(actingUserId());

  sortBySelect(users, SORTS)
    .filter((u) => showInactive || u.Status === "Active")
    .forEach((u) => {
      const isActive = u.Status === "Active";
      const isSelf = Number(u.UserID) === me;
      const row = document.createElement("tr");
      if (!isActive) row.classList.add("table-secondary");

      row.innerHTML = `
        <td>${esc(u.FirstName)} ${esc(u.LastName)}${isSelf ? ' <span class="badge bg-info text-dark">You</span>' : ""}</td>
        <td>${esc(u.Username)}</td>
        <td>${esc(u.Phone)}</td>
        <td>${esc(u.RoleName)}</td>
        <td>${u.RoleName === "Patient" ? esc(u.PatientName ? `Patient: ${u.PatientName}` : "") : esc(u.Specializations)}</td>
        <td><span class="badge ${isActive ? "bg-success" : "bg-secondary"}">${esc(u.Status)}</span></td>
        <td>
          <button type="button" class="btn btn-primary btn-sm btn-view">View</button>
          <button type="button" class="btn btn-success btn-sm btn-update">Edit</button>
          ${
            isActive
              ? (isSelf ? "" : `<button type="button" class="btn btn-danger btn-sm btn-delete">Deactivate</button>`)
              : `<button type="button" class="btn btn-warning btn-sm btn-restore">Restore</button>`
          }
        </td>
      `;
      tbody.appendChild(row);

      row.querySelector(".btn-view").addEventListener("click", () => viewModal(u.UserID));
      row.querySelector(".btn-update").addEventListener("click", () => updateModal(u.UserID, displayUsers));
      row.querySelector(".btn-delete")?.addEventListener("click", () => deleteModal(u.UserID, displayUsers));
      row.querySelector(".btn-restore")?.addEventListener("click", () => restoreUser(u.UserID));
    });

  table.appendChild(tbody);
  const scrollBox = document.createElement("div");
  scrollBox.className = "table-scroll";
  scrollBox.appendChild(table);
  tableDiv.appendChild(scrollBox);
};

const insertUser = async () => {
  const jsonData = {
    actingUserId: actingUserId(),
    firstName: document.getElementById("first-name").value,
    lastName: document.getElementById("last-name").value,
    username: document.getElementById("username").value,
    password: document.getElementById("password").value,
    roleId: document.getElementById("role").value,
    phone: document.getElementById("phone").value,
  };
  if (!Validate.ok("user_insert", jsonData)) return;

  if (!isValidPhone(jsonData.phone)) {
    alert("Phone must contain digits only (7-15 digits), with no negative sign or letters.");
    return;
  }
  if (isDoctorRoleSelected()) {
    jsonData.specializationIds = getSelectedSpecializationIds();
  }
  if (isPatientRoleSelected()) {
    jsonData.patientId = document.getElementById("patient-link").value;
    if (!jsonData.patientId) {
      alert("Please select the patient record this login belongs to.");
      return;
    }
  }

  const formData = new FormData();
  formData.append("operation", "insertUser");
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({ url: `${baseApiUrl}/users.php`, method: "POST", data: formData });

  if (checkResult(response.data, "Account successfully created!")) {
    clearForm();
    displayUsers();
  }
};

const restoreUser = async (userId) => {
  const response = await axios.get(`${baseApiUrl}/users.php`, {
    params: {
      operation: "restoreUser",
      json: JSON.stringify({ userId, actingUserId: actingUserId() }),
    },
  });
  if (checkResult(response.data, "Account restored!")) displayUsers();
};

const clearForm = () => {
  ["first-name", "last-name", "username", "password"].forEach((id) => (document.getElementById(id).value = ""));
  document.getElementById("role").value = "";
  document.getElementById("phone").value = "";
  document
    .querySelectorAll("#specializations input[type='checkbox']")
    .forEach((checkbox) => (checkbox.checked = false));
  document.getElementById("patient-link").value = "";
  ["first-name", "last-name", "phone"].forEach((id) => (document.getElementById(id).readOnly = false));
  document.getElementById("patient-details").style.display = "none";
  toggleDoctorFields();
  togglePatientFields();
};
