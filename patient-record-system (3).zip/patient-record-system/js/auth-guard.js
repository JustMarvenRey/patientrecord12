// auth-guard.js — runs on every protected page
// Responsibilities:
//   1. Redirect to login if no session
//   2. Render "Signed in as ..." + Logout in the navbar
//   3. Enforce role-based access per the permission map below:
//        Admin  → Master files full CRUD (incl. Diagnoses / ICD-10 and Laboratory Tests)
//                 + Patients / Appointments / Consultations / Billing: can UPDATE and
//                   DEACTIVATE (or restore) records, but does not ADD new ones
//                   (except bills + professional fees, which Admin fully controls)
//                 + Billing page also has the Admin-only Fee Schedule tab
//        Doctor → Own Appointments + Consultations (full CRUD) + Patients (view-only)
//                 + Diagnoses / ICD-10 master file (full CRUD)
//                 + Laboratory Tests master file (full CRUD) + consultation-detail
//        Staff  → Appointments + Patients (add / update, but no Deactivate / Restore)
//                 + Consultations: view the overall consultations of all doctors (view-only)
//                 + Billing: handles patient bills (create/edit/record payment) and professional fees
//        Patient → Dashboard + their OWN medical records (read-only), My Appointments (book /
//                 cancel online) and My Bills (view + pay online). The account is linked to one
//                 PATIENT record (USERS.PatientID).

// ── Session ────────────────────────────────────────────────────────────────
const getCurrentUser = () => {
  const raw = sessionStorage.getItem("currentUser");
  return raw ? JSON.parse(raw) : null;
};

const currentUser = getCurrentUser();

if (!currentUser) {
  window.location.href = "login.html";
}

// ── Role permission map ─────────────────────────────────────────────────────
const ROLE_PERMISSIONS = {
  Admin: {
    allowed: [
      "home", "index", "appointments", "consultations", "consultation-detail",
      "doctors", "medicines", "specializations", "generics",
      "diagnoses", "roles", "users", "laboratory-tests", "billing", "medical-history",
      "receipt",   // printable receipt of a paid bill
    ],
    viewOnly: [],
    // Pages where the Admin does NOT get the "add new record" form (the
    // Update / Deactivate / Restore buttons stay available on these pages).
    hideAddForm: ["index", "appointments", "consultations"],
    // Admin can view consultation-detail to manage Billing + Professional Fees
  },
  Doctor: {
    allowed: [
      "home",
      "index",                  // Patients — view only
      "appointments",           // own appointments
      "consultations",          // own consultations
      "consultation-detail",    // full detail page: vitals + diagnoses + (later) labs, prescriptions
      "diagnoses",              // ICD-10 master file — full CRUD (Admin has it too)
      "laboratory-tests",       // Laboratory Tests master file — full CRUD
      "medical-history",        // opened from Patients > View > View Medical History
    ],
    viewOnly: ["index"],
  },
  Staff: {
    allowed: [
      "home",
      "index",            // Patients — add / update (Deactivate + Restore hidden, see hideDeactivate)
      "appointments",     // full CRUD
      "consultations",    // overall consultations (all doctors) — VIEW only, no add / edit / deactivate
      "consultation-detail", // read-only detail; Staff can still create/edit the bill here
      "billing",          // creates/edits patient bills, records payment, manages professional fees
      "receipt",          // printable receipt of a paid bill
      "medical-history",     // opened from Patients > View > View Medical History
    ],
    viewOnly: [],
    hideDeactivate: ["index"],   // Staff can't Deactivate / Restore patients (Admin only)
  },
  Patient: {
    allowed: [
      "home",
      "medical-history",  // their own medical records only (medical-history.js pins the patientId)
      "my-appointments",  // book / cancel their own appointments
      "my-bills",         // view + pay their own bills online
      "receipt",          // printable receipt of their own paid bills
    ],
    viewOnly: [],
  },
};

// ── Current page ────────────────────────────────────────────────────────────
const getPageName = () => {
  const file = window.location.pathname.split("/").pop().replace(".html", "") || "home";
  return file;
};

const pageName = getPageName();

// ── Access check — redirect if this role can't be here ──────────────────────
const enforcePageAccess = () => {
  if (!currentUser) return;
  const perms = ROLE_PERMISSIONS[currentUser.RoleName];
  if (!perms) return; // unknown role — let it through, Admin controls roles

  if (!perms.allowed.includes(pageName)) {
    // Redirect to home with a message in sessionStorage
    sessionStorage.setItem(
      "accessDeniedMsg",
      `Your role (${currentUser.RoleName}) does not have access to that page.`
    );
    window.location.href = "home.html";
  }
};

enforcePageAccess();

// ── Navbar: sign-in info + logout ───────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  if (!currentUser) return;

  // 0. Fix navbar brand — remove the hardcoded "- Admin" suffix
  const brand = document.querySelector(".navbar-brand");
  if (brand) brand.textContent = "Patient Record System";

  // 1. Render user info + logout in topbar
  const slot = document.getElementById("nav-user-info");
  if (slot) {
    const initials = (currentUser.FirstName[0] + currentUser.LastName[0]).toUpperCase();
    slot.innerHTML = `
      <div class="user-chip">
        <div class="user-avatar">${initials}</div>
        <div class="d-none d-md-block">
          <div style="font-weight:600;line-height:1.1;">${currentUser.FirstName} ${currentUser.LastName}</div>
          <div style="font-size:.72rem;opacity:.8;">${currentUser.RoleName}</div>
        </div>
      </div>
      <button class="btn-logout" id="btn-logout">Sign Out</button>
    `;
    document.getElementById("btn-logout").addEventListener("click", () => {
      sessionStorage.removeItem("currentUser");
      window.location.href = "login.html";
    });
  }

  // 1b. Patients get a small, dedicated sidebar (the shared one lists staff modules)
  if (currentUser.RoleName === "Patient") {
    const side = document.querySelector(".prs-sidebar");
    if (side) {
      side.innerHTML = `
        <div class="nav-section-label">Main</div>
        <a class="nav-link ${pageName === "home" ? "active" : ""}" href="home.html" data-module="home"><span class="ni">🏠</span> Dashboard</a>
        <a class="nav-link ${pageName === "medical-history" ? "active" : ""}" href="medical-history.html" data-module="medical-history"><span class="ni">📁</span> My Medical Records</a>
        <a class="nav-link ${pageName === "my-appointments" ? "active" : ""}" href="my-appointments.html" data-module="my-appointments"><span class="ni">📅</span> My Appointments</a>
        <a class="nav-link ${pageName === "my-bills" ? "active" : ""}" href="my-bills.html" data-module="my-bills"><span class="ni">💳</span> My Bills</a>
      `;
    }
  }

  // 2. Hide sidebar nav links the role can't access
  const perms = ROLE_PERMISSIONS[currentUser.RoleName];
  if (perms) {
    // Sidebar links (a.nav-link with data-module)
    document.querySelectorAll(".prs-sidebar a.nav-link").forEach((link) => {
      const mod = link.getAttribute("data-module") || link.getAttribute("href")?.replace(".html","") || "";
      if (!perms.allowed.includes(mod)) link.style.display = "none";
    });
    // Hide section labels (Main / Master Files / System) with no visible link under them
    const sidebarEl = document.querySelector(".prs-sidebar");
    if (sidebarEl) {
      let label = null;
      let hasVisibleLink = false;
      const flush = () => { if (label) label.style.display = hasVisibleLink ? "" : "none"; };
      [...sidebarEl.children].forEach((el) => {
        if (el.classList.contains("nav-section-label")) {
          flush();
          label = el;
          hasVisibleLink = false;
        } else if (el.matches("a.nav-link") && el.style.display !== "none") {
          hasVisibleLink = true;
        }
      });
      flush();
    }
    // Old navbar nav-items (for pages not yet migrated to sidebar)
    document.querySelectorAll(".navbar-nav .nav-item").forEach((item) => {
      const link = item.querySelector("a.nav-link");
      if (!link) return;
      const href = link.getAttribute("href") || "";
      const linkPage = href.replace(".html", "") || "home";
      if (!perms.allowed.includes(linkPage)) item.style.display = "none";
    });
  }

  // 3. Show access-denied flash if redirected here
  if (pageName === "home") {
    const msg = sessionStorage.getItem("accessDeniedMsg");
    if (msg) {
      sessionStorage.removeItem("accessDeniedMsg");
      const banner = document.createElement("div");
      banner.className = "alert alert-warning alert-dismissible fade show mx-3 mt-3";
      banner.innerHTML = `${msg} <button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
      document.querySelector(".container")?.prepend(banner);
    }
  }

  // 3b. Hide the "add new record" form only (keeps Update / Deactivate / Restore).
  //     Anything marked #add-form-fields or .add-only is hidden; if a page has
  //     neither, the whole #main-div card is hidden.
  if (perms && (perms.hideAddForm || []).includes(pageName)) {
    const addOnly = document.querySelectorAll("#add-form-fields, .add-only");
    if (addOnly.length) {
      addOnly.forEach((el) => (el.style.display = "none"));
    } else {
      const mainDiv = document.getElementById("main-div");
      if (mainDiv) mainDiv.style.display = "none";
    }
  }

  // 4. View-only: hide Add form + strip Update/Delete/Restore buttons
  if (perms && perms.viewOnly.includes(pageName)) {
    // Hide the add/edit form card
    const mainDiv = document.getElementById("main-div");
    if (mainDiv) mainDiv.style.display = "none";

    // Strip action buttons from the table every time it re-renders
    const tableDiv = document.getElementById("table-div");
    if (tableDiv) {
      const strip = () => {
        tableDiv.querySelectorAll(".btn-update, .btn-delete, .btn-restore").forEach((btn) => btn.remove());
      };
      strip();
      new MutationObserver(strip).observe(tableDiv, { childList: true, subtree: true });
    }
  }

  // 5. Hide Deactivate / Restore for roles that may still add + update on this page
  //    (e.g. Staff on Patients). Update stays; the add form stays.
  if (perms && (perms.hideDeactivate || []).includes(pageName)) {
    const tableDiv = document.getElementById("table-div");
    if (tableDiv) {
      const strip = () => {
        tableDiv.querySelectorAll(".btn-delete, .btn-restore").forEach((btn) => btn.remove());
      };
      strip();
      new MutationObserver(strip).observe(tableDiv, { childList: true, subtree: true });
    }
  }
});
