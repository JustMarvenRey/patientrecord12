// Patient self-service: book an appointment online and manage my own appointments.
// The server takes the patient from the logged-in account, so only my own record can be booked/cancelled.
const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const currentUser = JSON.parse(sessionStorage.getItem("currentUser") || "null");
const actingUserId = currentUser?.UserID;

const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

const formatTime = (t) => {
  if (!t) return "";
  const [h, m] = t.split(":");
  const hour = Number(h);
  return `${hour % 12 || 12}:${m} ${hour >= 12 ? "PM" : "AM"}`;
};

const STATUS_BADGE = { Scheduled: "bg-primary", Completed: "bg-success", Cancelled: "bg-secondary", "No-Show": "bg-warning text-dark" };

const showAlert = (message, type = "danger") => {
  const box = document.getElementById("book-alert");
  box.className = `alert alert-${type} mb-2`;
  box.textContent = message;
};
const hideAlert = () => document.getElementById("book-alert").classList.add("d-none");

document.addEventListener("DOMContentLoaded", async () => {
  if (!currentUser || currentUser.RoleName !== "Patient") return;
  document.getElementById("appt-date").min = todayStr();
  document.getElementById("btn-book").addEventListener("click", bookAppointment);
  await Promise.all([loadDoctors(), loadAppointments()]);
});

const loadDoctors = async () => {
  const sel = document.getElementById("appt-doctor");
  try {
    const res = await axios.get(`${baseApiUrl}/appointments.php`, { params: { operation: "getActiveDoctors" } });
    sel.innerHTML = `<option value="">Select doctor</option>` +
      res.data.map((d) => `<option value="${d.UserID}">${esc(d.DoctorName)} — ${esc(d.Specializations || "No specialization")}</option>`).join("");
  } catch (e) {
    sel.innerHTML = `<option value="">Could not load doctors</option>`;
  }
};

const bookAppointment = async () => {
  hideAlert();
  const payload = {
    actingUserId,
    userId: document.getElementById("appt-doctor").value,
    appointmentDate: document.getElementById("appt-date").value,
    appointmentTime: document.getElementById("appt-time").value,
    reason: document.getElementById("appt-reason").value.trim(),
    notes: document.getElementById("appt-notes").value.trim(),
  };
  if (!payload.userId) return showAlert("Please select a doctor.");
  if (!payload.appointmentDate) return showAlert("Please choose a date.");
  if (!payload.appointmentTime) return showAlert("Please choose a time.");
  if (!payload.reason) return showAlert("Please tell us the reason for your visit.");

  const btn = document.getElementById("btn-book");
  btn.disabled = true;
  try {
    const formData = new FormData();
    formData.append("operation", "bookMyAppointment");
    formData.append("json", JSON.stringify(payload));
    const res = await axios({ url: `${baseApiUrl}/appointments.php`, method: "POST", data: formData });
    if (res.data == 1) {
      showAlert("Appointment booked! You can see it in the list below.", "success");
      ["appt-doctor", "appt-date", "appt-time", "appt-reason", "appt-notes"].forEach((id) => (document.getElementById(id).value = ""));
      await loadAppointments();
    } else if (res.data?.error === "validation") {
      showAlert(res.data.message);
    } else if (res.data?.error === "forbidden") {
      showAlert("Your account can't book appointments.");
    } else {
      showAlert("Could not book the appointment. Please try again.");
    }
  } catch (e) {
    showAlert("Could not reach the server. Please try again.");
  } finally {
    btn.disabled = false;
  }
};

const loadAppointments = async () => {
  const list = document.getElementById("appt-list");
  try {
    const res = await axios.get(`${baseApiUrl}/appointments.php`, {
      params: { operation: "getMyAppointments", json: JSON.stringify({ actingUserId }) },
    });
    if (!Array.isArray(res.data)) throw new Error("bad response");
    renderAppointments(res.data);
  } catch (e) {
    list.innerHTML = `<div class="form-card text-center text-muted py-4">Could not load your appointments.</div>`;
  }
};

const renderAppointments = (rows) => {
  const list = document.getElementById("appt-list");
  if (rows.length === 0) {
    list.innerHTML = `<div class="form-card text-center text-muted py-4">You have no appointments yet.</div>`;
    return;
  }
  const now = new Date();
  list.innerHTML = `
    <div class="table-scroll">
      <table class="table table-hover table-striped table-sm">
        <thead><tr><th>DATE</th><th>TIME</th><th title="Your place in line for this doctor and time (first to request is #1)">QUEUE</th><th>DOCTOR</th><th>REASON</th><th>STATUS</th><th></th></tr></thead>
        <tbody>
          ${rows.map((a) => {
            const when = new Date(`${a.AppointmentDate}T${a.AppointmentTime}`);
            const canCancel = a.Status === "Scheduled" && when > now;
            return `
              <tr>
                <td>${esc(a.AppointmentDate)}</td>
                <td>${esc(formatTime(a.AppointmentTime))}</td>
                <td>${a.QueueNumber ? `<span class="badge bg-primary">#${esc(a.QueueNumber)}</span>` : "—"}</td>
                <td>${esc(a.DoctorName)}</td>
                <td>${esc(a.Reason ?? "—")}</td>
                <td><span class="badge ${STATUS_BADGE[a.Status] || "bg-secondary"}">${esc(a.Status)}</span></td>
                <td>${canCancel ? `<button type="button" class="btn btn-danger btn-sm btn-cancel" data-id="${esc(a.AppointmentID)}">Cancel</button>` : ""}</td>
              </tr>`;
          }).join("")}
        </tbody>
      </table>
    </div>`;
  list.querySelectorAll(".btn-cancel").forEach((btn) =>
    btn.addEventListener("click", () => cancelAppointment(btn.dataset.id))
  );
};

const cancelAppointment = async (appointmentId) => {
  if (!confirm("Cancel this appointment?")) return;
  hideAlert();
  try {
    const formData = new FormData();
    formData.append("operation", "cancelMyAppointment");
    formData.append("json", JSON.stringify({ actingUserId, appointmentId }));
    const res = await axios({ url: `${baseApiUrl}/appointments.php`, method: "POST", data: formData });
    if (res.data == 1) {
      showAlert("Appointment cancelled.", "success");
      await loadAppointments();
    } else {
      showAlert(res.data?.message || "Could not cancel the appointment.");
    }
  } catch (e) {
    showAlert("Could not reach the server. Please try again.");
  }
};
