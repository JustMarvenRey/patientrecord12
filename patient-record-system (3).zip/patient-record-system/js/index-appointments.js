const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const CAN_UPDATE_CANCEL = ["Admin", "Staff"]; // only these roles see Update/Cancel
let currentUser = null;

document.addEventListener("DOMContentLoaded", async () => {
  currentUser = JSON.parse(sessionStorage.getItem("currentUser"));
  if (!currentUser) return;

  // Changing the sort or a filter goes back to page 1
  const firstPage = () => { pagerState.page = 1; renderSorted(); };
  document.getElementById("sort-by").addEventListener("change", firstPage);
  wireStatusTabs();

  // Doctors can't book appointments — hide the form entirely
  if (currentUser.RoleName === "Doctor") {
    document.getElementById("main-div")?.remove();
    displayAppointments();
    return;
  }

  await loadDropdowns();
  displayAppointments();

  document.getElementById("btn-submit").addEventListener("click", insertAppointment);
});

// ── Dropdowns ───────────────────────────────────────────────────────────────
const loadDropdowns = async () => {
  // Patients
  const pRes = await axios.get(`${baseApiUrl}/patients.php`, {
    params: { operation: "getActivePatients" },
  });
  const patientSel = document.getElementById("appt-patient");
  patientSel.innerHTML = `<option value="" disabled selected>Select Patient</option>`;
  pRes.data.forEach((p) => {
    patientSel.innerHTML += `<option value="${p.PatientID}">${p.LastName}, ${p.FirstName}</option>`;
  });

  // Block past dates in the date picker
  document.getElementById("appt-date").min = todayStr();

  // Doctors
  const dRes = await axios.get(`${baseApiUrl}/appointments.php`, {
    params: { operation: "getActiveDoctors" },
  });
  const doctorSel = document.getElementById("appt-doctor");
  const doctorWrap = document.getElementById("doctor-field-wrap");

  if (currentUser.RoleName === "Doctor") {
    // Doctor is booking for themselves — lock the field to their own account
    doctorWrap.innerHTML = `
      <label class="form-label">Doctor</label>
      <input type="text" class="form-control" value="${currentUser.LastName}, ${currentUser.FirstName}" disabled />
      <input type="hidden" id="appt-doctor" value="${currentUser.UserID}" />
    `;
  } else {
    doctorSel.innerHTML = `<option value="" disabled selected>Select Doctor</option>`;
    dRes.data.forEach((d) => {
      doctorSel.innerHTML += `<option value="${d.UserID}">${doctorLabel(d)}</option>`;
    });
  }
};

// ── Fetch & render table ────────────────────────────────────────────────────
const displayAppointments = async () => {
  let response;
  if (currentUser.RoleName === "Doctor") {
    response = await axios.get(`${baseApiUrl}/appointments.php`, {
      params: {
        operation: "getAppointmentsByDoctor",
        json: JSON.stringify({ userId: currentUser.UserID }),
      },
    });
  } else {
    response = await axios.get(`${baseApiUrl}/appointments.php`, {
      params: { operation: "getAllAppointments" },
    });
  }

  if (response.status === 200) {
    appointmentRows = response.data;
    renderSorted();
  } else alert("Error loading appointments.");
};

// ── Sorting ─────────────────────────────────────────────────────────────────
let appointmentRows = [];
const pagerState = { page: 1, size: 10 };

const cmpRaw = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
const dateTimeKey = (r) => `${r.AppointmentDate} ${r.AppointmentTime ?? ""}`;
// Same time slot: whoever submitted first (smaller queue number) comes first
const byQueue = (a, b) => (Number(a.QueueNumber) || 0) - (Number(b.QueueNumber) || 0) || a.AppointmentID - b.AppointmentID;

const APPT_SORTS = {
  // Next up: appointments still waiting (Scheduled) first, soonest date & time at the top so
  // staff can see who is next; finished / cancelled ones after, newest first.
  "next":         (a, b) => {
    const pa = a.Status === "Scheduled" ? 0 : 1, pb = b.Status === "Scheduled" ? 0 : 1;
    if (pa !== pb) return pa - pb;
    const c = cmpRaw(dateTimeKey(a), dateTimeKey(b));
    if (pa === 0) return c || byQueue(a, b);
    return -c || byQueue(a, b);
  },
  "date-desc":    (a, b) => cmpRaw(dateTimeKey(b), dateTimeKey(a)) || byQueue(a, b),
  "date-asc":     (a, b) => cmpRaw(dateTimeKey(a), dateTimeKey(b)) || byQueue(a, b),
};

// ── Status tabs: Scheduled / Completed / Cancelled are shown as separate lists ──
const KNOWN_STATUSES = ["Scheduled", "Completed", "Cancelled"];
let activeStatus = "Scheduled";
const statusGroup = (r) => (KNOWN_STATUSES.includes(r.Status) ? r.Status : "Other");

const wireStatusTabs = () => {
  document.querySelectorAll("#status-tabs [data-status]").forEach((btn) =>
    btn.addEventListener("click", () => {
      activeStatus = btn.dataset.status;
      pagerState.page = 1;
      renderSorted();
    })
  );
};

const updateStatusTabs = () => {
  const counts = { Scheduled: 0, Completed: 0, Cancelled: 0, Other: 0 };
  appointmentRows.forEach((r) => counts[statusGroup(r)]++);
  if (activeStatus === "Other" && counts.Other === 0) activeStatus = "Scheduled";
  Object.keys(counts).forEach((k) => (document.getElementById(`count-${k}`).textContent = counts[k]));
  document.getElementById("tab-other").style.display = counts.Other > 0 ? "" : "none";
  document.querySelectorAll("#status-tabs [data-status]").forEach((btn) =>
    btn.classList.toggle("active", btn.dataset.status === activeStatus)
  );
};

const renderSorted = () => {
  const sortKey = document.getElementById("sort-by").value;
  updateStatusTabs();
  const rows = appointmentRows.filter((r) => statusGroup(r) === activeStatus);
  const sorted = rows.sort(APPT_SORTS[sortKey]);
  renderTable(Pager.paginate(pagerState, sorted));
  Pager.controls(document.getElementById("pager"), pagerState, sorted.length, renderSorted);
};

const renderTable = (rows) => {
  const tableDiv = document.getElementById("table-div");
  tableDiv.innerHTML = "";

  if (!rows || rows.length === 0) {
    tableDiv.innerHTML = `<p class="text-muted">No appointments found.</p>`;
    return;
  }

  const canModify = CAN_UPDATE_CANCEL.includes(currentUser.RoleName);
  const isAdmin = currentUser.RoleName === "Admin";
  const isStaff = currentUser.RoleName === "Staff"; // Staff take the vital signs

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");
  table.innerHTML = `
    <thead>
      <tr>
        <th class="text-nowrap">REQUESTED</th>
        <th>DATE</th>
        <th>TIME</th>
        <th class="text-nowrap" title="Order of arrival for the same doctor and time: who submitted first is #1">QUEUE</th>
        <th>PATIENT</th>
        <th>DOCTOR</th>
        <th>REASON</th>
        <th>STATUS</th>
        <th>ACTION</th>
      </tr>
    </thead>
  `;

  const tbody = document.createElement("tbody");
  rows.forEach((row) => {
    const badge = badgeColor(row.Status);
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="text-nowrap small">${row.CreatedAt ? row.CreatedAt.slice(0, 16).replace("T", " ") : "—"}</td>
      <td>${row.AppointmentDate}</td>
      <td>${formatTime(row.AppointmentTime)}</td>
      <td>${row.QueueNumber ? `<span class="badge bg-primary">#${row.QueueNumber}</span>` : "—"}</td>
      <td>${row.PatientName}</td>
      <td>${row.DoctorName}</td>
      <td>${row.Reason ?? "—"}</td>
      <td><span class="badge ${badge}">${row.Status}</span></td>
      <td>
        <button class="btn btn-primary btn-sm btn-view me-1">View</button>
        ${isStaff && row.Status !== "Cancelled"
          ? (Number(row.HasVitals) > 0
              ? `<button class="btn btn-info btn-sm btn-vitals me-1">Edit Vital Signs</button>`
              : `<button class="btn btn-warning btn-sm btn-vitals me-1">Record Vital Signs</button>`)
          : ""}
        ${canModify && row.Status === "Scheduled"
          ? `<button class="btn btn-success btn-sm btn-update me-1">Edit</button>
             <button class="btn btn-danger btn-sm btn-cancel">${isAdmin ? "Deactivate" : "Cancel"}</button>`
          : ""}
        ${isAdmin && row.Status === "Cancelled"
          ? `<button class="btn btn-warning btn-sm btn-restore">Restore</button>`
          : ""}
      </td>
    `;
    tbody.appendChild(tr);

    tr.querySelector(".btn-view").addEventListener("click", () => viewAppointment(row));
    tr.querySelector(".btn-vitals")?.addEventListener("click", () => openVitals(row));
    if (canModify && row.Status === "Scheduled") {
      tr.querySelector(".btn-update").addEventListener("click", () => showUpdateModal(row));
      tr.querySelector(".btn-cancel").addEventListener("click", () => cancelAppointment(row));
    }
    tr.querySelector(".btn-restore")?.addEventListener("click", () => restoreAppointment(row));
  });

  table.appendChild(tbody);
  const scrollBox = document.createElement("div");
  scrollBox.className = "table-scroll";
  scrollBox.appendChild(table);
  tableDiv.appendChild(scrollBox);
};

// ── Vital signs (Staff) ──────────────────────────────────────────────────────
const openVitals = async (row) => {
  let existing = null;
  if (Number(row.HasVitals) > 0) {
    const res = await axios.get(`${baseApiUrl}/vital-signs.php`, {
      params: { operation: "getVitalSignByAppointment", json: JSON.stringify({ appointmentId: row.AppointmentID }) },
    });
    existing = res.data?.[0] ?? null;
  }
  showIntakeModal({
    appointmentId: row.AppointmentID,
    patientName:   row.PatientName,
    dateLabel:     `${row.AppointmentDate} ${formatTime(row.AppointmentTime)}`,
    intake:        { reason: row.Reason },
    vitals:        existing,
    onSaved:       displayAppointments,
  });
};

// ── View modal ──────────────────────────────────────────────────────────────
const viewAppointment = (row) => {
  document.getElementById("blank-modal-title").innerText = "Appointment Details";
  document.getElementById("blank-main-div").innerHTML = `
    <table class="table table-sm">
      <tr><td><strong>Patient</strong></td><td>${row.PatientName}</td></tr>
      <tr><td><strong>Doctor</strong></td><td>${row.DoctorName}</td></tr>
      <tr><td><strong>Requested</strong></td><td>${row.CreatedAt ?? "—"}</td></tr>
      <tr><td><strong>Date</strong></td><td>${row.AppointmentDate}</td></tr>
      <tr><td><strong>Time</strong></td><td>${formatTime(row.AppointmentTime)}</td></tr>
      <tr><td><strong>Queue number</strong></td><td>${row.QueueNumber ? `#${row.QueueNumber} (by who requested first for this doctor and time)` : "—"}</td></tr>
      <tr><td><strong>Reason</strong></td><td>${row.Reason ?? "—"}</td></tr>
      <tr><td><strong>Notes</strong></td><td>${row.Notes ?? "—"}</td></tr>
      <tr><td><strong>Status</strong></td><td><span class="badge ${badgeColor(row.Status)}">${row.Status}</span></td></tr>
    </table>
  `;
  document.getElementById("blank-modal-footer").innerHTML = `
    <button type="button" class="btn btn-secondary btn-sm w-100" data-bs-dismiss="modal">Close</button>
  `;
  new bootstrap.Modal(document.getElementById("blank-modal"), { backdrop: "static" }).show();
};

// ── Update modal (Admin/Staff only) ────────────────────────────────────────
const showUpdateModal = async (row) => {
  // Load fresh doctor list for the dropdown
  const dRes = await axios.get(`${baseApiUrl}/appointments.php`, {
    params: { operation: "getActiveDoctors" },
  });
  const pRes = await axios.get(`${baseApiUrl}/patients.php`, {
    params: { operation: "getActivePatients" },
  });

  const doctorOptions = dRes.data.map((d) =>
    `<option value="${d.UserID}" ${d.UserID == row.UserID ? "selected" : ""}>${doctorLabel(d)}</option>`
  ).join("");
  const patientOptions = pRes.data.map((p) =>
    `<option value="${p.PatientID}" ${p.PatientID == row.PatientID ? "selected" : ""}>${p.LastName}, ${p.FirstName}</option>`
  ).join("");

  const statusOptions = ["Scheduled", "Completed", "Cancelled", "No-Show"].map((s) =>
    `<option value="${s}" ${s === row.Status ? "selected" : ""}>${s}</option>`
  ).join("");

  document.getElementById("update-modal-body").innerHTML = `
    <div class="row g-2">
      <div class="col-md-6">
        <label class="form-label">Patient <span class="text-danger">*</span></label>
        <select class="form-select" id="upd-patient" data-v="appointment.patientId">${patientOptions}</select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Doctor <span class="text-danger">*</span></label>
        <select class="form-select" id="upd-doctor" data-v="appointment.userId">${doctorOptions}</select>
      </div>
      <div class="col-md-4">
        <label class="form-label">Date <span class="text-danger">*</span></label>
        <input type="date" class="form-control" id="upd-date" data-v="appointment.appointmentDate" data-v-original="${row.AppointmentDate}" value="${row.AppointmentDate}" />
      </div>
      <div class="col-md-4">
        <label class="form-label">Time <span class="text-danger">*</span></label>
        <input type="time" class="form-control" id="upd-time" data-v="appointment.appointmentTime" value="${row.AppointmentTime}" />
      </div>
      <div class="col-md-4">
        <label class="form-label">Status</label>
        <select class="form-select" id="upd-status" data-v="appointment.status">${statusOptions}</select>
      </div>
      <div class="col-12">
        <label class="form-label">Reason</label>
        <input type="text" class="form-control" id="upd-reason" data-v="appointment.reason" value="${row.Reason ?? ""}" />
      </div>
      <div class="col-12">
        <label class="form-label">Notes</label>
        <textarea class="form-control" id="upd-notes" data-v="appointment.notes" rows="2">${row.Notes ?? ""}</textarea>
      </div>
    </div>
  `;

  document.getElementById("update-modal-footer").innerHTML = `
    <button type="button" class="btn btn-success btn-sm me-2" id="btn-save-update">Save Changes</button>
    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
  `;

  const modal = new bootstrap.Modal(document.getElementById("update-modal"), { backdrop: "static" });
  modal.show();

  document.getElementById("btn-save-update").addEventListener("click", async () => {
    const data = {
      appointmentId:   row.AppointmentID,
      patientId:       document.getElementById("upd-patient").value,
      userId:          document.getElementById("upd-doctor").value,
      appointmentDate: document.getElementById("upd-date").value,
      appointmentTime: document.getElementById("upd-time").value,
      status:          document.getElementById("upd-status").value,
      reason:          document.getElementById("upd-reason").value,
      notes:           document.getElementById("upd-notes").value,
    };

    // "Not in the past" is only enforced when the date was actually changed, so an old
    // appointment can still be marked Completed / No-Show.
    const relax = data.appointmentDate === row.AppointmentDate ? ["notPast"] : [];
    if (!Validate.ok("appointment", data, { relax })) return;
    const rowTime = String(row.AppointmentTime ?? "").slice(0, 5);
    if (data.appointmentDate !== row.AppointmentDate || data.appointmentTime.slice(0, 5) !== rowTime) {
      const timeErr = Validate.timePassedToday(data.appointmentDate, data.appointmentTime);
      if (timeErr) { alert(timeErr); return; }
    }

    const fd = new FormData();
    fd.append("operation", "updateAppointment");
    fd.append("json", JSON.stringify(data));
    const res = await axios({ url: `${baseApiUrl}/appointments.php`, method: "POST", data: fd });

    if (res.data == 1) {
      modal.hide();
      displayAppointments();
      alert("Appointment updated!");
    } else {
      alert(res.data?.error === "date_in_past" ? "Appointment date cannot be in the past." : "ERROR updating appointment.");
    }
  });
};

// ── Cancel (Admin/Staff only) ───────────────────────────────────────────────
const cancelAppointment = async (row) => {
  const adminUser = currentUser.RoleName === "Admin";
  if (!(await showConfirm(
    adminUser
      ? `Deactivate appointment for ${row.PatientName} on ${row.AppointmentDate}? It will be marked Cancelled and can be restored later.`
      : `Cancel appointment for ${row.PatientName} on ${row.AppointmentDate}?`,
    {
      type: "danger",
      title: adminUser ? "Deactivate appointment" : "Cancel appointment",
      confirmText: adminUser ? "Deactivate" : "Yes, cancel",
      cancelText: "Keep",
    }
  ))) return;
  const fd = new FormData();
  fd.append("operation", "cancelAppointment");
  fd.append("json", JSON.stringify({ appointmentId: row.AppointmentID }));
  const res = await axios({ url: `${baseApiUrl}/appointments.php`, method: "POST", data: fd });
  if (res.data == 1) {
    displayAppointments();
    alert("Appointment cancelled.");
  } else {
    alert("ERROR cancelling appointment.");
  }
};

// ── Restore (Admin only) ────────────────────────────────────────────────────
const restoreAppointment = async (row) => {
  const fd = new FormData();
  fd.append("operation", "restoreAppointment");
  fd.append("json", JSON.stringify({ appointmentId: row.AppointmentID }));
  const res = await axios({ url: `${baseApiUrl}/appointments.php`, method: "POST", data: fd });
  if (res.data == 1) {
    displayAppointments();
    alert("Appointment restored (set back to Scheduled).");
  } else {
    alert("ERROR restoring appointment.");
  }
};

// ── Insert (all roles) ──────────────────────────────────────────────────────
const insertAppointment = async () => {
  const patientId = document.getElementById("appt-patient").value;
  const userId    = document.getElementById("appt-doctor").value;
  const date      = document.getElementById("appt-date").value;
  const time      = document.getElementById("appt-time").value;

  const isStaff = currentUser.RoleName === "Staff";
  const patientName = document.getElementById("appt-patient").selectedOptions[0]?.textContent ?? "";

  const data = {
    patientId,
    userId,
    appointmentDate: date,
    appointmentTime: time,
    reason: document.getElementById("appt-reason").value,
    notes:  document.getElementById("appt-notes").value,
    returnId: isStaff, // Staff need the new AppointmentID to record vital signs
  };
  if (!Validate.ok("appointment", data)) return;
  const timeErr = Validate.timePassedToday(data.appointmentDate, data.appointmentTime);
  if (timeErr) { alert(timeErr); return; }

  const fd = new FormData();
  fd.append("operation", "insertAppointment");
  fd.append("json", JSON.stringify(data));
  const res = await axios({ url: `${baseApiUrl}/appointments.php`, method: "POST", data: fd });

  if (res.data == 1) {
    clearForm();
    displayAppointments();
    alert("Appointment booked successfully!");
  } else if (res.data?.appointmentId) {
    // Staff: booking is done — go straight to the patient's vital signs (no extra question)
    clearForm();
    displayAppointments();
    alert("Appointment booked successfully!");
    showIntakeModal({
      appointmentId: res.data.appointmentId,
      patientName,
      dateLabel: `${date} ${formatTime(time)}`,
      intake: { reason: data.reason },
      vitals: null,
      onSaved: displayAppointments,
    });
  } else if (res.data?.error === "date_in_past") {
    alert("Appointment date cannot be in the past.");
  } else if (res.data?.error === "missing_required_fields") {
    alert("Please fill in all required fields.");
  } else {
    alert("ERROR booking appointment.");
  }
};

const clearForm = () => {
  document.getElementById("appt-patient").value = "";
  const doctorEl = document.getElementById("appt-doctor");
  if (doctorEl && doctorEl.tagName === "SELECT") doctorEl.value = "";
  document.getElementById("appt-date").value   = "";
  document.getElementById("appt-time").value   = "";
  document.getElementById("appt-reason").value = "";
  document.getElementById("appt-notes").value  = "";
  document.querySelectorAll("#add-form-fields .is-invalid, #main-div .is-invalid").forEach((el) => el.classList.remove("is-invalid"));
  document.querySelectorAll("#main-div .v-msg").forEach((el) => el.remove());
};

// ── Helpers ─────────────────────────────────────────────────────────────────
// Today as YYYY-MM-DD in the user's local time (not UTC)
const todayStr = () => {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
};

// "Dela Cruz, Juan — Cardiology" (or "— No specialization")
const doctorLabel = (d) => `${d.DoctorName} — ${d.Specializations || "No specialization"}`;

const formatTime = (t) => {
  if (!t) return "";
  const [h, m] = t.split(":");
  const hr = parseInt(h);
  return `${hr % 12 || 12}:${m} ${hr < 12 ? "AM" : "PM"}`;
};

const badgeColor = (status) => {
  switch (status) {
    case "Completed":  return "bg-success";
    case "Scheduled":  return "bg-primary";
    case "Cancelled":  return "bg-danger";
    case "No-Show":    return "bg-warning text-dark";
    default:           return "bg-secondary";
  }
};
