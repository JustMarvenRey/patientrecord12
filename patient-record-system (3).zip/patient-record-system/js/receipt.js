// Built-in system receipt for a PAID bill.   receipt.html?bill=<BillID>
// Admin / Staff can open any paid bill's receipt; a Patient only their own (checked on the server).
const baseApiUrl = "http://localhost/patient-record-system/api";

// Shown at the top of every receipt. Fill in the address / phone to have them printed.
const CLINIC = {
  name: "Patient Record System",
  address: "",
  phone: "",
};

const currentUser = JSON.parse(sessionStorage.getItem("currentUser") || "null");

const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const peso = (n) => `₱ ${(parseFloat(n) || 0).toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const fmtDate = (d) => {
  if (!d) return "—";
  const dt = new Date(String(d).slice(0, 10) + "T00:00:00");
  return isNaN(dt) ? esc(d) : dt.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
};
const fmtDateTime = (d) => {
  if (!d) return "—";
  const dt = new Date(String(d).replace(" ", "T"));
  return isNaN(dt) ? esc(d) : dt.toLocaleString("en-US", { year: "numeric", month: "long", day: "numeric", hour: "numeric", minute: "2-digit" });
};

const ERRORS = {
  not_found: "That receipt was not found.",
  not_paid: "A receipt is only available once the bill has been paid.",
  forbidden: "Your account can't view this receipt.",
};

document.addEventListener("DOMContentLoaded", async () => {
  if (!currentUser) return;
  const root = document.getElementById("receipt-root");

  // Back goes to the page the user came from: patients to My Bills, staff to Billing
  document.getElementById("btn-back").href = currentUser.RoleName === "Patient" ? "my-bills.html" : "billing.html";
  document.getElementById("btn-print").addEventListener("click", () => window.print());

  const billId = new URLSearchParams(window.location.search).get("bill");
  if (!billId) return showMessage(root, ERRORS.not_found);

  try {
    const res = await axios.get(`${baseApiUrl}/billing.php`, {
      params: { operation: "getReceipt", json: JSON.stringify({ actingUserId: currentUser.UserID, billId }) },
    });
    if (res.data?.error) return showMessage(root, ERRORS[res.data.error] || "The receipt could not be loaded.");
    root.innerHTML = receiptHtml(res.data);
    document.getElementById("btn-print").style.display = "";
    document.title = `Receipt ${res.data.receiptNo}`;
  } catch (e) {
    showMessage(root, "Could not reach the server. Please try again.");
  }
});

const showMessage = (root, message) => {
  root.innerHTML = `<div class="receipt-paper text-center"><p class="mb-0">${esc(message)}</p></div>`;
};

const receiptHtml = ({ receiptNo, bill, fees, labs, payment }) => {
  // Itemised lines: professional fees, then laboratory charges
  const lines = [
    ...fees.map((f) => ({
      label: `${f.Description ? esc(f.Description) : "Professional fee"} <span class="text-muted">(Dr. ${esc(f.DoctorName)})</span>`,
      amount: parseFloat(f.FeeAmount) || 0,
    })),
    ...labs.map((l) => ({ label: `Laboratory: ${esc(l.TestName)}`, amount: parseFloat(l.Price) || 0 })),
  ];
  const itemised = lines.reduce((sum, l) => sum + l.amount, 0);
  const total = parseFloat(bill.TotalAmount) || 0;
  // Bills made before totals were calculated can have a typed total that differs from their lines
  const diff = Math.round((total - itemised) * 100) / 100;
  if (Math.abs(diff) >= 0.01) lines.push({ label: "Other charges / adjustments", amount: diff });

  const paidOn = payment ? fmtDateTime(payment.PaidAt) : "—";
  const clinicInfo = [CLINIC.address, CLINIC.phone].filter(Boolean).map(esc).join(" · ");

  return `
  <div class="receipt-paper">
    <div class="stamp">PAID</div>

    <div class="receipt-head">
      <div class="clinic">${esc(CLINIC.name)}</div>
      ${clinicInfo ? `<div class="small text-muted">${clinicInfo}</div>` : ""}
      <div class="title">OFFICIAL RECEIPT</div>
    </div>

    <table class="receipt-meta w-100 mb-3">
      <tr><td>Receipt no.</td><td><strong>${esc(receiptNo)}</strong></td></tr>
      <tr><td>Date paid</td><td>${payment ? paidOn : fmtDate(bill.BillDate)}</td></tr>
      <tr><td>Patient</td><td><strong>${esc(bill.PatientName)}</strong></td></tr>
      <tr><td>Attending doctor</td><td>Dr. ${esc(bill.DoctorName)}</td></tr>
      <tr><td>Consultation date</td><td>${fmtDate(bill.ConsultationDate)}</td></tr>
      <tr><td>Bill no. / date</td><td>#${esc(bill.BillID)} · ${fmtDate(bill.BillDate)}</td></tr>
    </table>

    <table class="receipt-items w-100">
      <thead><tr><th>Description</th><th class="text-end">Amount</th></tr></thead>
      <tbody>
        ${lines.length
          ? lines.map((l) => `<tr><td>${l.label}</td><td class="text-end">${peso(l.amount)}</td></tr>`).join("")
          : `<tr><td class="text-muted">Consultation charges</td><td class="text-end">${peso(total)}</td></tr>`}
        <tr class="total"><td>TOTAL</td><td class="text-end">${peso(total)}</td></tr>
      </tbody>
    </table>

    <div class="receipt-paybox">
      <table class="receipt-meta w-100">
        <tr><td>Amount paid</td><td><strong>${peso(payment ? payment.Amount : total)}</strong></td></tr>
        <tr><td>Payment method</td><td>${payment ? `${esc(payment.Method)} (${esc(payment.Channel)})` : "Paid at the clinic"}</td></tr>
        ${payment ? `<tr><td>Reference no.</td><td>${esc(payment.ReferenceNo)}</td></tr>` : ""}
        ${payment?.ReceivedBy ? `<tr><td>Received by</td><td>${esc(payment.ReceivedBy)}</td></tr>` : ""}
        <tr><td>Status</td><td><strong class="text-success">PAID IN FULL</strong></td></tr>
      </table>
    </div>

    <div class="receipt-foot">
      This is a system-generated receipt and is valid without a signature.<br/>
      Thank you.
    </div>
  </div>`;
};
