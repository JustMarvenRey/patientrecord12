import { cmpText, cmpNum, sortBySelect } from "./sort-utils.js?v=20261107";
import { viewModal } from "./modules-medicines/view.js?v=20261107";
import { updateModal } from "./modules-medicines/update.js?v=20261107";
import { deleteModal } from "./modules-medicines/delete.js?v=20261107";

const baseApiUrl = "http://localhost/patient-record-system/api";
sessionStorage.setItem("baseAPIUrl", baseApiUrl);

const SORTS = {
  "name-asc":    (a, b) => cmpText(a.MedicineName, b.MedicineName),
  "name-desc":   (a, b) => cmpText(b.MedicineName, a.MedicineName),
  "generic-asc": (a, b) => cmpText(a.GenericName, b.GenericName) || cmpText(a.MedicineName, b.MedicineName),
  "form-asc":    (a, b) => cmpText(a.DosageForm, b.DosageForm) || cmpText(a.MedicineName, b.MedicineName),
  "status-asc":  (a, b) => cmpText(a.Status, b.Status) || cmpText(a.MedicineName, b.MedicineName),
};

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("sort-by").addEventListener("change", () => displayMedicines());
  loadGenericsDropdown();
  displayMedicines();

  document.getElementById("btn-submit").addEventListener("click", () => {
    insertMedicine();
  });

  document.getElementById("show-inactive").addEventListener("change", () => {
    displayMedicines();
  });
});

const loadGenericsDropdown = async () => {
  const response = await axios.get(`${baseApiUrl}/generics.php`, {
    params: { operation: "getActiveGenerics" },
  });
  const select = document.getElementById("generic-id");
  response.data.forEach((generic) => {
    const option = document.createElement("option");
    option.value = generic.GenericID;
    option.innerText = generic.GenericName;
    select.appendChild(option);
  });
};

const displayMedicines = async () => {
  const response = await axios.get(`${baseApiUrl}/medicines.php`, {
    params: { operation: "getAllMedicines" },
  });
  if (response.status == 200) {
    displayMedicinesTable(response.data);
  } else {
    alert("Error!");
  }
};

const displayMedicinesTable = (medicines) => {
  const showInactive = document.getElementById("show-inactive").checked;
  const tableDiv = document.getElementById("table-div");
  tableDiv.innerHTML = "";

  const table = document.createElement("table");
  table.classList.add("table", "table-hover", "table-striped", "table-sm");

  const thead = document.createElement("thead");
  thead.innerHTML = `
    <tr>
      <th>MEDICINE NAME</th>
      <th>GENERIC</th>
      <th>DOSAGE FORM</th>
      <th>DESCRIPTION</th>
      <th>STATUS</th>
      <th>ACTION</th>
    </tr>
  `;
  table.appendChild(thead);

  const tbody = document.createElement("tbody");

  sortBySelect(medicines, SORTS)
    .filter((medicine) => showInactive || medicine.Status === "Active")
    .forEach((medicine) => {
      const isActive = medicine.Status === "Active";
      let row = document.createElement("tr");
      if (!isActive) row.classList.add("table-secondary");

      row.innerHTML = `
        <td>${medicine.MedicineName}</td>
        <td>${medicine.GenericName ?? "<em class='text-muted'>None</em>"}</td>
        <td>${medicine.DosageForm}</td>
        <td>${medicine.Description ?? ""}</td>
        <td>
          <span class="badge ${isActive ? "bg-success" : "bg-secondary"}">${medicine.Status}</span>
        </td>
        <td>
          <button type="button" class="btn btn-primary btn-sm btn-view">View</button>
          <button type="button" class="btn btn-success btn-sm btn-update">Edit</button>
          ${
            isActive
              ? `<button type="button" class="btn btn-danger btn-sm btn-delete">Deactivate</button>`
              : `<button type="button" class="btn btn-warning btn-sm btn-restore">Restore</button>`
          }
        </td>
      `;
      tbody.appendChild(row);

      row.querySelector(".btn-view").addEventListener("click", () => {
        viewModal(medicine.MedicineID);
      });

      row.querySelector(".btn-update").addEventListener("click", () => {
        updateModal(medicine.MedicineID, displayMedicines);
      });

      const deleteBtn = row.querySelector(".btn-delete");
      if (deleteBtn) {
        deleteBtn.addEventListener("click", () => {
          deleteModal(medicine.MedicineID, displayMedicines);
        });
      }

      const restoreBtn = row.querySelector(".btn-restore");
      if (restoreBtn) {
        restoreBtn.addEventListener("click", () => {
          restoreMedicine(medicine.MedicineID);
        });
      }
    });

  table.appendChild(tbody);
  const scrollBox = document.createElement("div");
  scrollBox.className = "table-scroll";
  scrollBox.appendChild(table);
  tableDiv.appendChild(scrollBox);
};

const insertMedicine = async () => {
  const jsonData = {
    medicineName: document.getElementById("medicine-name").value,
    genericId: document.getElementById("generic-id").value,
    dosageForm: document.getElementById("dosage-form").value,
    description: document.getElementById("description").value,
  };
  if (!Validate.ok("medicine", jsonData)) return;

  if (!jsonData.medicineName || !jsonData.dosageForm) {
    alert("Please fill in Medicine Name and Dosage Form.");
    return;
  }

  const formData = new FormData();
  formData.append("operation", "insertMedicine");
  formData.append("json", JSON.stringify(jsonData));

  const response = await axios({
    url: `${baseApiUrl}/medicines.php`,
    method: "POST",
    data: formData,
  });

  if (response.data == 1) {
    clearForm();
    displayMedicines();
    alert("Medicine successfully saved!");
  } else {
    alert("ERROR");
  }
};

const restoreMedicine = async (medicineId) => {
  const params = {
    operation: "restoreMedicine",
    json: JSON.stringify({ medicineId: medicineId }),
  };
  const response = await axios.get(`${sessionStorage.baseAPIUrl}/medicines.php`, {
    params: params,
  });
  if (response.data == 1) {
    displayMedicines();
    alert("Medicine restored!");
  } else {
    alert("ERROR");
  }
};

const clearForm = () => {
  document.getElementById("medicine-name").value = "";
  document.getElementById("generic-id").value = "";
  document.getElementById("dosage-form").value = "";
  document.getElementById("description").value = "";
};
