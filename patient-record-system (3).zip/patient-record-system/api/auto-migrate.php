<?php
// Brings an older database up to the schema the current code expects.
// Safe to run repeatedly: each step only runs if its column/constraint is missing,
// and nothing is ever dropped or deleted. Called from connection-pdo.php.
if (!function_exists('ensureSchema')) {
    function ensureSchema($conn) {
        static $done = false;
        if ($done) return;
        $done = true;

        try {
            $db = $conn->query("SELECT DATABASE()")->fetchColumn();

            $has = function ($table, $column = null) use ($conn, $db) {
                if ($column === null) {
                    $q = $conn->prepare("SELECT COUNT(*) FROM information_schema.TABLES
                                         WHERE TABLE_SCHEMA = :db AND TABLE_NAME = :t");
                    $q->execute([":db" => $db, ":t" => $table]);
                } else {
                    $q = $conn->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS
                                         WHERE TABLE_SCHEMA = :db AND TABLE_NAME = :t AND COLUMN_NAME = :c");
                    $q->execute([":db" => $db, ":t" => $table, ":c" => $column]);
                }
                return $q->fetchColumn() > 0;
            };
            $run = function ($sql) use ($conn) {
                try { $conn->exec($sql); } catch (PDOException $e) { error_log("auto-migrate: " . $e->getMessage()); }
            };

            // 1. Staff intake: APPOINTMENT.ChiefComplaint / Symptoms
            if ($has("APPOINTMENT") && !$has("APPOINTMENT", "ChiefComplaint")) {
                $run("ALTER TABLE APPOINTMENT ADD COLUMN ChiefComplaint TEXT NULL, ADD COLUMN Symptoms TEXT NULL");
                if ($has("CONSULTATION")) {
                    $run("UPDATE APPOINTMENT a JOIN CONSULTATION c ON c.AppointmentID = a.AppointmentID
                          SET a.ChiefComplaint = c.ChiefComplaint, a.Symptoms = c.Symptoms");
                }
            }

            // 2. First come, first served: remember WHEN each request was submitted.
            //    (NULL for old rows - their order is still known from AppointmentID.)
            if ($has("APPOINTMENT") && !$has("APPOINTMENT", "CreatedAt")) {
                $run("ALTER TABLE APPOINTMENT ADD COLUMN CreatedAt DATETIME NULL DEFAULT NULL");
            }

            // 3. Vital signs belong to the appointment (recorded by Staff before the consultation)
            if ($has("VITAL_SIGN") && !$has("VITAL_SIGN", "AppointmentID")) {
                $run("ALTER TABLE VITAL_SIGN ADD COLUMN AppointmentID INT NULL AFTER VitalSignID");
                if ($has("CONSULTATION")) {
                    $run("UPDATE VITAL_SIGN v JOIN CONSULTATION c ON c.ConsultationID = v.ConsultationID
                          SET v.AppointmentID = c.AppointmentID");
                }
                $run("ALTER TABLE VITAL_SIGN MODIFY ConsultationID INT NULL");
                $run("ALTER TABLE VITAL_SIGN ADD CONSTRAINT uq_vital_appointment UNIQUE (AppointmentID)");
                $run("ALTER TABLE VITAL_SIGN ADD CONSTRAINT fk_vital_appointment
                      FOREIGN KEY (AppointmentID) REFERENCES APPOINTMENT(AppointmentID)");
            }

            // 4. Specializations are deactivated (soft delete) instead of permanently deleted
            if ($has("SPECIALIZATION") && !$has("SPECIALIZATION", "Status")) {
                $run("ALTER TABLE SPECIALIZATION ADD COLUMN Status VARCHAR(10) NOT NULL DEFAULT 'Active'");
            }

            // 5. Patient logins: a USERS row with the 'Patient' role is linked to the PATIENT
            //    record it may view (USERS.PatientID). One login per patient (UNIQUE).
            if ($has("USERS") && !$has("USERS", "PatientID")) {
                $run("ALTER TABLE USERS ADD COLUMN PatientID INT NULL DEFAULT NULL");
                if ($has("PATIENT")) {
                    $run("ALTER TABLE USERS ADD CONSTRAINT uq_users_patient UNIQUE (PatientID)");
                    $run("ALTER TABLE USERS ADD CONSTRAINT fk_users_patient
                          FOREIGN KEY (PatientID) REFERENCES PATIENT(PatientID)");
                }
            }
            if ($has("ROLE")) {
                $exists = $conn->query("SELECT COUNT(*) FROM ROLE WHERE RoleName = 'Patient'")->fetchColumn();
                if ($exists == 0) {
                    $run("INSERT INTO ROLE (RoleName, Description, Status)
                          VALUES ('Patient', 'Patients who can view their own medical records', 'Active')");
                }
            }

            // 6. Online payments by patients: one PAYMENT row per successful payment of a bill.
            //    (No card numbers are ever stored - only the method and a reference number.)
            if (!$has("PAYMENT") && $has("BILLING")) {
                $run("CREATE TABLE PAYMENT (
                        PaymentID INT AUTO_INCREMENT PRIMARY KEY,
                        BillID INT NOT NULL,
                        Amount DECIMAL(10,2) NOT NULL,
                        Method VARCHAR(30) NOT NULL,
                        ReferenceNo VARCHAR(40) NOT NULL,
                        Channel VARCHAR(10) NOT NULL DEFAULT 'Online',
                        PaidByUserID INT NULL,
                        PaidAt DATETIME NOT NULL,
                        UNIQUE KEY uq_payment_ref (ReferenceNo),
                        KEY idx_payment_bill (BillID),
                        CONSTRAINT fk_payment_bill FOREIGN KEY (BillID) REFERENCES BILLING(BillID)
                      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                if (!$has("PAYMENT")) {   // the foreign key was refused (older column types): keep going without it
                    $run("CREATE TABLE PAYMENT (
                            PaymentID INT AUTO_INCREMENT PRIMARY KEY, BillID INT NOT NULL, Amount DECIMAL(10,2) NOT NULL,
                            Method VARCHAR(30) NOT NULL, ReferenceNo VARCHAR(40) NOT NULL,
                            Channel VARCHAR(10) NOT NULL DEFAULT 'Online', PaidByUserID INT NULL, PaidAt DATETIME NOT NULL,
                            UNIQUE KEY uq_payment_ref (ReferenceNo), KEY idx_payment_bill (BillID)
                          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                }
            }

            // 7. Billing = professional fees + laboratory charges.
            //    LABORATORY_TEST.Price is the current price list; LABORATORY.Price is a copy taken
            //    when the test is ordered, so changing the price list later never alters old bills.
            if ($has("LABORATORY_TEST") && !$has("LABORATORY_TEST", "Price")) {
                $run("ALTER TABLE LABORATORY_TEST ADD COLUMN Price DECIMAL(10,2) NOT NULL DEFAULT 0.00");
            }
            if ($has("LABORATORY") && !$has("LABORATORY", "Price")) {
                $run("ALTER TABLE LABORATORY ADD COLUMN Price DECIMAL(10,2) NULL DEFAULT NULL");
                if ($has("LABORATORY_TEST")) {
                    $run("UPDATE LABORATORY l JOIN LABORATORY_TEST t ON t.TestID = l.TestID SET l.Price = t.Price");
                }
            }

            // 8. Laboratory fees an Admin adds straight onto a bill (on top of the tests recorded
            //    for the consultation, which are priced in LABORATORY.Price).
            if ($has("BILLING") && !$has("BILL_LAB_CHARGE")) {
                $run("CREATE TABLE BILL_LAB_CHARGE (
                          LabChargeID INT AUTO_INCREMENT PRIMARY KEY,
                          BillID      INT NOT NULL,
                          TestID      INT NULL,
                          Description VARCHAR(150) NOT NULL,
                          Amount      DECIMAL(10,2) NOT NULL,
                          Status      VARCHAR(10) NOT NULL DEFAULT 'Active',
                          KEY idx_blc_bill (BillID),
                          CONSTRAINT fk_blc_bill FOREIGN KEY (BillID) REFERENCES BILLING(BillID)
                      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            }

            // 9. Fee schedule: the Admin sets each doctor's professional fee (USERS.ProfessionalFee).
            //    A new bill gets the consulting doctor's fee automatically.
            if ($has("USERS") && !$has("USERS", "ProfessionalFee")) {
                $run("ALTER TABLE USERS ADD COLUMN ProfessionalFee DECIMAL(10,2) NOT NULL DEFAULT 0.00");
            }
        } catch (PDOException $e) {
            error_log("auto-migrate: " . $e->getMessage());
        }
    }
}
