<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
require_once __DIR__ . "/validation.php";

class Specialization {

    // Used to populate the specialization checkboxes on the User Accounts / Doctors forms.
    // Returns every row WITH its Status: the pickers only offer Active ones, but an edit form
    // still shows a deactivated specialization the doctor already has (so saving doesn't drop it).
    function getSpecializations() {
        include "connection-pdo.php";
        $sql = "SELECT * FROM SPECIALIZATION ORDER BY SpecializationName";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return json_encode($rs);
    }

    // Returns ALL specializations (Active + Inactive) - used by the admin master file table.
    function getAllSpecializations() {
        include "connection-pdo.php";
        $sql = "SELECT s.*,
                       (SELECT COUNT(*) FROM DOCTOR_SPECIALIZATION ds
                        WHERE ds.SpecializationID = s.SpecializationID) AS DoctorCount
                FROM SPECIALIZATION s
                ORDER BY s.SpecializationName";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return json_encode($rs);
    }

    function getSpecialization($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        $sql = "SELECT * FROM SPECIALIZATION WHERE SpecializationID = :specializationId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":specializationId", $json['specializationId']);
        $stmt->execute();
        $rs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return json_encode($rs);
    }

    // Case-insensitive, whitespace-trimmed duplicate check. $excludeId lets
    // updateSpecialization ignore the row being edited (so saving a record
    // without changing its name doesn't flag itself as a duplicate).
    private function specializationNameExists($conn, $name, $excludeId = null) {
        $sql = "SELECT COUNT(*) AS cnt FROM SPECIALIZATION
                WHERE LOWER(TRIM(SpecializationName)) = LOWER(TRIM(:name))";
        if ($excludeId !== null) {
            $sql .= " AND SpecializationID != :excludeId";
        }
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":name", $name);
        if ($excludeId !== null) {
            $stmt->bindParam(":excludeId", $excludeId);
        }
        $stmt->execute();
        return (int) $stmt->fetch(PDO::FETCH_ASSOC)['cnt'] > 0;
    }

    function insertSpecialization($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        list($err, $json) = Validator::run("specialization", $json);
        if ($err) return Validator::fail($err);
        $name = trim($json['name']);

        if ($name === "") {
            return json_encode(["error" => "empty_name"]);
        }
        if ($this->specializationNameExists($conn, $name)) {
            return json_encode(["error" => "duplicate"]);
        }

        $sql = "INSERT INTO SPECIALIZATION(SpecializationName, Description)
                VALUES(:name, :description)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":description", $json['description']);
        $stmt->execute();
        $returnValue = $stmt->rowCount() > 0 ? 1 : 0;
        return json_encode($returnValue);
    }

    function updateSpecialization($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if ($e = Validator::badId($json, ['specializationId'])) return Validator::fail($e);
        list($err, $json) = Validator::run("specialization", $json);
        if ($err) return Validator::fail($err);
        $name = trim($json['name']);

        if ($name === "") {
            return json_encode(["error" => "empty_name"]);
        }
        if ($this->specializationNameExists($conn, $name, $json['specializationId'])) {
            return json_encode(["error" => "duplicate"]);
        }

        $sql = "UPDATE SPECIALIZATION
                SET SpecializationName = :name, Description = :description
                WHERE SpecializationID = :specializationId";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":description", $json['description']);
        $stmt->bindParam(":specializationId", $json['specializationId']);
        $stmt->execute();
        return Validator::saved($conn, $stmt, 'SPECIALIZATION', 'SpecializationID', $json['specializationId']);
    }

    // SOFT DELETE (Deactivate): the row is kept and marked Inactive, the same as the other master files.
    // Doctors who already have this specialization keep it; it just stops being offered when a
    // specialization is picked for a doctor. Reverse it with restoreSpecialization.
    function deleteSpecialization($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if ($e = Validator::badId($json, ['specializationId'])) return Validator::fail($e);
        $stmt = $conn->prepare("UPDATE SPECIALIZATION SET Status = 'Inactive' WHERE SpecializationID = :id");
        $stmt->bindParam(":id", $json['specializationId']);
        $stmt->execute();
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }

    // Reverses a deactivate
    function restoreSpecialization($json) {
        include "connection-pdo.php";
        $json = json_decode($json, true);
        if ($e = Validator::badId($json, ['specializationId'])) return Validator::fail($e);
        $stmt = $conn->prepare("UPDATE SPECIALIZATION SET Status = 'Active' WHERE SpecializationID = :id");
        $stmt->bindParam(":id", $json['specializationId']);
        $stmt->execute();
        return json_encode($stmt->rowCount() > 0 ? 1 : 0);
    }
}

// submitted by the client - operation and json
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $operation = $_GET['operation'];
    $json = isset($_GET['json']) ? $_GET['json'] : "";
} else if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $operation = $_POST['operation'];
    $json = isset($_POST['json']) ? $_POST['json'] : "";
}

$specialization = new Specialization();
switch ($operation) {
    case "getSpecializations":
        echo $specialization->getSpecializations();
        break;
    case "getAllSpecializations":
        echo $specialization->getAllSpecializations();
        break;
    case "getSpecialization":
        echo $specialization->getSpecialization($json);
        break;
    case "insertSpecialization":
        echo $specialization->insertSpecialization($json);
        break;
    case "updateSpecialization":
        echo $specialization->updateSpecialization($json);
        break;
    case "deleteSpecialization":
        echo $specialization->deleteSpecialization($json);
        break;
    case "restoreSpecialization":
        echo $specialization->restoreSpecialization($json);
        break;
}
?>
