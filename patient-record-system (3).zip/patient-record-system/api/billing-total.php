<?php
// A bill's total is NEVER typed in. It is always:
//
//     total = active professional fees on the bill
//           + price of every active laboratory test recorded for the bill's consultation
//           + laboratory fees an Admin added directly to the bill (BILL_LAB_CHARGE)
//
// recalcBillTotal() is called whenever one of those changes (a fee is added/removed, a lab test is
// ordered/changed/removed, the bill is created). Only a Pending bill is recalculated: once a bill is
// Paid or Cancelled its amount is frozen.
if (!function_exists('billTotals')) {
    // [fees, labs, total] for a bill, as numbers
    function billTotals($conn, $billId) {
        $f = $conn->prepare("SELECT COALESCE(SUM(FeeAmount), 0) FROM PROFESSIONAL_FEE
                             WHERE BillID = :bid AND Status = 'Active'");
        $f->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
        $f->execute();
        $fees = round((float)$f->fetchColumn(), 2);

        $l = $conn->prepare("SELECT COALESCE(SUM(COALESCE(l.Price, 0)), 0)
                             FROM LABORATORY l
                             JOIN BILLING b ON b.ConsultationID = l.ConsultationID
                             WHERE b.BillID = :bid AND l.Status = 'Active'");
        $l->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
        $l->execute();
        $labs = round((float)$l->fetchColumn(), 2);

        $c = $conn->prepare("SELECT COALESCE(SUM(Amount), 0) FROM BILL_LAB_CHARGE
                             WHERE BillID = :bid AND Status = 'Active'");
        $c->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
        $c->execute();
        $labs = round($labs + (float)$c->fetchColumn(), 2);

        return [$fees, $labs, round($fees + $labs, 2)];
    }
}

if (!function_exists('recalcBillTotal')) {
    function recalcBillTotal($conn, $billId) {
        $s = $conn->prepare("SELECT Status FROM BILLING WHERE BillID = :bid");
        $s->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
        $s->execute();
        if ($s->fetchColumn() !== 'Pending') return;

        list(, , $total) = billTotals($conn, $billId);
        $u = $conn->prepare("UPDATE BILLING SET TotalAmount = :t WHERE BillID = :bid AND Status = 'Pending'");
        $u->bindValue(":t", number_format($total, 2, '.', ''));
        $u->bindValue(":bid", (int)$billId, PDO::PARAM_INT);
        $u->execute();
    }
}

if (!function_exists('recalcBillForConsultation')) {
    // Used by the laboratory API: find the consultation's bill (if it has one) and refresh it.
    function recalcBillForConsultation($conn, $consultationId) {
        $s = $conn->prepare("SELECT BillID FROM BILLING WHERE ConsultationID = :cid");
        $s->bindValue(":cid", (int)$consultationId, PDO::PARAM_INT);
        $s->execute();
        $billId = $s->fetchColumn();
        if ($billId !== false) recalcBillTotal($conn, $billId);
    }
}
